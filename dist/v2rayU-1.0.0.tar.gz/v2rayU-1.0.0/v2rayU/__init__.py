__version__ = '1.0.0'

from .util_core.trans import _