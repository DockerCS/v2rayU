__version__ = '1.2.1'

from .util_core.trans import _